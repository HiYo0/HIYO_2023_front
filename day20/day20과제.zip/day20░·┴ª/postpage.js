let 매개변수 = JSON.parse(localStorage.getItem("매개변수"))


글보기(매개변수)

function 글보기(index){
    let userArray = JSON.parse(localStorage.getItem('userArray'));
    
    const 출력좌표 = document.querySelector("#출력좌표")
    
    // 조회수 추가하기
    let 조회수1 = userArray[index].조회수
    조회수1 += 1/* 조회수 추가하기 출력당 */
    console.log(typeof(userArray[index].조회수))
    
    // localStorage.setItem(userArray[index].조회수,조회수1) 틀림
    console.log(userArray)                          /* 대상불러옴 */
    console.log(userArray[index])                   /* 불러온대상에서 필요한 객체 찾음 */
    console.log(userArray[index].조회수 = 조회수1)   /* 그안에 조회수 +1 한거 로 바꿈 */
    console.log(userArray[index])       /* 확인용 */
    console.log(조회수1)                /* 확인용 */
    // localStorage.setItem("조회수",조회수1)
    // console.log(Number(userArray[index].조회수))
    
    
                
    let html = `<div> 작성자 : ${userArray[index].id} 조회수 : ${userArray[index].조회수}</div>
                <div> 제목 : ${userArray[index].title} </div>
                <div> 내용 : ${userArray[index].content.replaceAll('\n','<br/>')} </div>
                <input onclick="글수정(${index})" type="button" value="수정"/>
                <input onclick="글삭제(${index})" type="button" value="삭제"/>
                `;

    출력좌표.innerHTML = html;
}
function 등록(){
    console.log("등록함수켜짐")
    // 1. 입력
    const mid = document.querySelector('#mid').value;
        console.log("아이디"+mid);
    const mpw = document.querySelector('#mpw').value;
        console.log("패스워드"+mpw);
    // 2. 처리
        // 1. {아이디와 비밀번호} 회원 를 객체화
    const member = {
        mid : mid,
        mpw : mpw
    };
        // 2. 객체를 배열에 저장. [전역변수]가 아닌[브라우저]에 저장.
        // localStorage 에 입력받은 객체를 저장한다. [ JSON.stringify(  ) : ror]

    let memberArray = JSON.parse(localStorage.getItem('memberArray')); // 기존 배열 호출
    if(memberArray==null){ memberArray=[] } // 배열을 새로 만들어준다.
    memberArray.push(member);   // 방금 가입된 회원객체를 배열에 추가


        
    localStorage.setItem('memberArray',JSON.stringify(memberArray))
    // 3. 출력[x]
    alert('회원가입 성공')
}//f end

function 글수정(매개변수){
    alert("만드는중")
}

function 글삭제(매개변수){
    // console.log("글삭제 실행됨")

}